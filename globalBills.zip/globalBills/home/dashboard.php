<?php

session_start();

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];


    $servername = "localhost:3306";  // Replace with your database server name
    $db_username = "qdbnrbnq_global";        // Replace with your database username
    $db_password = "Sinachi123";            // Replace with your database password
    $db_name = "qdbnrbnq_global"; // Replace with your database name



    $conn = new mysqli($servername, $db_username, $db_password, $db_name);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve the user's virtual account balance
    $user_id_query = "SELECT user_id FROM users WHERE username = ?";
    $stmt = $conn->prepare($user_id_query);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $user_id = $row["user_id"];

        // Retrieve the user's balance
        $balance_query = "SELECT balance FROM virtual_accounts WHERE acct_id = ?";
        $stmt = $conn->prepare($balance_query);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $balance_result = $stmt->get_result();

        if ($balance_result->num_rows == 1) {
            $balance_row = $balance_result->fetch_assoc();
            $account_balance = $balance_row["balance"];

            $_SESSION['acct'] = $account_balance;
        } else {
            $account_balance = 0; // Default balance if not found
        }
    } else {
        // Handle the case where the user's ID is not found
        header("Location: ../home/login.php"); // Redirect to the dashboard page
        exit;
    }

}


// Get the current hour
$currentHour = date('H');

// Customize the greeting based on the time of the day
if ($currentHour >= 1 && $currentHour < 12) {
    $greeting = "Good morning";
} elseif ($currentHour >= 12 && $currentHour < 18) {
    $greeting = "Good afternoon";
} else {
    $greeting = "Good evening";
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
<link rel="stylesheet" href="../css/dashboard.css">
    <link rel="icon" type="image/png" size="512x512" href="../css/imgs/EPIbg.png">
    <script src="https://kit.fontawesome.com/49c5823e25.js" crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>

    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-VVN0P5EYQP">
</script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-VVN0P5EYQP');
</script>
</head>

<body>
    <header>
        <div class="container container-nav">
                <div class="all">
                    <diV class="logo">
                        <img src="../css/imgs/EPbg.png">
                    </div>
                    <div class="tilte">
                        <h1>EAZI PLUX</h1>
                        <p class="subtitle">Designed for Eased Payment</p>
                    </div>
                </div>
            <nav>
                <ul>
                    <li><a href="../home/dashboard.php">Dashboard</a></li>
                    <li><a href="../dashboard/buyairtime.php">Airtime</a></li>
                    <li><a href="../dashboard/tvsub.php">Data</a></li>
                    <li><?php if (isset($_SESSION['username'])): ?>
                        <?php ?><a href="logout.php">logout</a>
                    <?php else: ?>
                        <?php ?><a href="login.php">Login</a>
                    <?php endif; ?></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <div class="container">
            <div class="baldash">
                <div class="bal">
                    <?php if (isset($_SESSION['username'])): ?>
                        <h5><?php echo $greeting." ".$_SESSION['username']; ?></h5>
                    <?php else: ?>
                        <h2><?php ?><a href="login.php">Login here.</a></h2>
                    <?php endif; ?>

                    <?php if (isset($account_balance)): ?>
                        <h1><i class="fa-solid fa-naira-sign"></i><?php echo $account_balance; ?></h1>
                    <?php else: ?>
                        <h1><i class="fa-solid fa-naira-sign"></i><?php echo "****"; ?> </h1>
                    <?php endif; ?>

                </div>
                <div class="add">

                    <div class="additems">
                        <a href="../dashboard/addfundamount.php">
                            <i class="fas fa-plus-square" aria-hidden="true"></i>
                            <p>Add Funds</p>
                        </a>
                    </div>

                    <div class="additems">
                        <a href="../dashboard/transaction.php">
                            <i class="fas fa-scroll"></i>
                            <p>Transactions</p>
                        </a>
                    </div>
                </div>
            </div>

            <div class="services">
                <div class="column">
                    <div class="col">
                        <a href="../dashboard/buyairtime.php">
                            <i class="fas fa-phone"></i>
                            <p>AIRTIME</p>
                        </a>
                    </div>
                    <div class="col">
                        <a href="../dashboard/buydata.php">
                            <i class="fas fa-wifi-strong"></i>
                            <p>DATA</p>
                        </a>
                    </div>
                    <div class="col">
                        <a href="#" onclick="unable()">
                            <i class="fas fa-print"></i>
                            <p>CARD</p>
                        </a>
                    </div>
                </div>

                <div class="column">
                    <div class="col">
                        <a href="#" onclick="unable()">
                            <i class="fas fa-graduation-cap"></i>
                            <p>E-PINS</p>
                        </a>
                    </div>
                    <div class="col">
                        <a href="../dashboard/electricity.php">
                            <i class="fas fa-plug"></i>
                            <p>ELECTRICITY</p>
                        </a>
                    </div>
                    <div class="col">
                        <a href="../dashboard/tvsub.php">
                            <i class="fas fa-television"></i>
                            <p>DSTV/GOTV</p>
                        </a>
                    </div>
                </div>

                <div class="column">
                    <div class="col">
                        <a href="#" onclick="lert()">
                        <!--    <i class="fas fa-gamepad"></i>
                        <p>GAMES</p>-->
                        </a>
                    </div>
                    <div class="col">
                        <a href="#" onclick="unable()">
                            <!--<i class="fas fa-soccer-ball"></i>
                            <p>BETTING</p>-->
                        </a>
                    </div>
                    <div class="col">
                        <a href="#" onclick="lert()">
                            <i class="fas fa-money-bill-transfer"></i>
                            <p>AIRTIME 2 CASH</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </main>



    <script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/658c01c070c9f2407f83aa82/1hilednbb';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
</body>
<script>
    function lert(){
        alert('COMING SOON👌');
    };

    function unable(){
        alert('CURRENTLY UNAVAILABLE⚠')
    };
</script>
</html>

