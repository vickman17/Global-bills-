<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" type="image/png" size="512x512" href="../css/imgs/EPIbg.png">
    <script src="https://kit.fontawesome.com/49c5823e25.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../css/ourservices.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OUR SERVICES</title>
</head>
<body>
<header>
        <div class="container container-nav">
            <div class="all">
            <diV class="logo">
                <img src="../css/imgs/EPbg.png">
            </div>
            <div class="tilte">
                <h1>EAZI PLUX</h1>
                <p class="subtitle">Designed for Eased Payment</p>
            </div>
        </div>
            <nav>
                <ul>
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="ourservices.php">Our Service</a></li>
                    <li><a href="getintouch.php">Get in Touch</a></li>
                    <li><a href="signup.php">Join US</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <div class="container">
            <div class="services">
                <h1>OUR SERVICES</h1>
                <p class="p">Services We Offer</p>
                <div class="column">
                    <div class="col">
                        <h1><i class="fas fa-wifi"></i></h1>
                        <h3>DATA</h3>
                        <p>Empowering Your Connectivity: Explore Eazi Plux for Unmatched 
                        Data Services! Enjoy seamless access to top-notch networks, including [MTN, AIRTEL, 9MOBILE, GLO]. From lightning-fast internet to reliable coverage, we've got your data needs covered. 
                        Elevate your connectivity experience with us – where speed meets reliability.</p>
                    </div>
                    <div class="col">
                        <h1><i class="fas fa-signal"></i></h1>
                        <h3>AIRTIME</h3>
                        <p>Stay Connected, Anytime, Anywhere! Eazi Plux brings you hassle-free airtime services across a range of networks, including [MTN, AIRTEL, 9MOBILE, GLO]. Recharge in seconds and enjoy uninterrupted communication. 
                        Your favorite networks, instant top-ups – because staying connected should be effortless!</p>
                    </div>
                    <div class="col">
                        <h1><i class="fas fa-receipt"></i></h1>
                        <h3>BILLS</h3>
                        <p>Simplify Your Life with Eazi Plux – Your One-Stop Bills Payment Solution! Easily manage and pay your bills hassle-free. From utilities to subscriptions, experience the convenience of centralized payments.
                         Swift, secure, and stress-free – handle your bills seamlessly with us. Your time, your way!</p>
                    </div>
                </div>
                <div class="column">
                    <div class="col">
                        <h1><i class="fas fa-plug"></i></h1>
                        <h3>ELECTRICITY</h3>
                        <p>Power Up Your Convenience: Electricity Payments Made Easy with Eazi Plux! Skip the queues and effortlessly pay your electricity bills online. Swift transactions, secure payments, and instant confirmations – experience the ease of managing your power needs. 
                        Empower your life with seamless electricity payments, all at your fingertips!</p>
                    </div>
                    <div class="col">
                        <h1><i class="fas fa-print"></i></h1>
                        <h3>CARD PRINTING</h3>
                        <p>Elevate Your Business: Recharge Card Printing and Resale Made Simple with Eazi Plux! Start your own venture effortlessly by printing and reselling recharge cards. Our platform offers user-friendly tools for bulk printing, secure transactions, and attractive profit margins. 
                        Empower your entrepreneurial spirit – dive into the world of recharge card resale with us!</p>
                    </div>
                    <div class="col">
                        <h1><i class="fas fa-television"></i></h1>
                        <h3>TV SUBSCRIPTION</h3>
                        <p>Uninterrupted Entertainment: Elevate Your TV Experience with Eazi Plux! Seamlessly subscribe to your favorite channels with just a few clicks. From sports to shows, we've got your entertainment covered. Enjoy instant activation, secure transactions, and a wide range of subscription options. 
                        Transform your TV time – subscribe hassle-free with us!</p>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <footer>
        <div class="footcontainer">
        <div class="allf">
            <diV class="logof">
                <img src="../css/imgs/EPbg.png">
            </div>
            <i class="fas fa-copyright">2023 EAZI PLUX. All Rights Reserved</i>
        </div>
        <div class="stamp">
            <p>Designed By Vickman Tech<i class="fas fa-registered">.</i></p>
        </div>
    </footer>



    <script type="text/javascript">
        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
        (function(){
        var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
        s1.async=true;
        s1.src='https://embed.tawk.to/658c01c070c9f2407f83aa82/1hilednbb';
        s1.charset='UTF-8';
        s1.setAttribute('crossorigin','*');
        s0.parentNode.insertBefore(s1,s0);
        })();
    </script>
</body>
</html>