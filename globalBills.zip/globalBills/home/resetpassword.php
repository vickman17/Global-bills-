<?php
    session_start();
?>


<!DOCTYPE html>
<html>
<head>
    <link rel="icon" type="image/png" size="512x512" href="../css/imgs/EPIbg.png">
    <link rel="stylesheet" href="../css/resetpassword.css">
    <title>Forgot Password</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <header>
        <div class="container container-nav">
            <div class="all">
                <diV class="logo">
                    <img src="../css/imgs/EPbg.png">
                </div>
                <div class="tilte">
                    <h1>EAZI PLUX</h1>
                    <p class="subtitle">Designed for Eased Payment</p>
                </div>
            </div>
            <div>
                <nav>
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a href="ourservices.php">Our Service</a></li>
                        <li><a href="getintouch.php">Get in Touch</a></li>
                        <li><a href="signup.php">Join Us</a></li>
                    </ul>
                </nav>
            </div>
    </header>
    <main>
        <div class="container">
            <h2>Forgot Password?</h2>
            <p>Enter your email address to reset your password.</p>
            <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                <div class="txt-field">
                    <input type="text" name="email">
                    <span></span>
                    <label>Email:</label>
                </div>
                <div>
                    <input name="submit" type="submit" value="Reset Password">
                </div>
            </form>
        </div>
    </main>
</body>

</html>

<?php



$servername = "localhost:3306";  // Replace with your database server name
$dbusername = "qdbnrbnq_global";        // Replace with your database username
$dbpassword = "Sinachi123";  // Replace with your database password
$database = "qdbnrbnq_global"; // Replace with your database name

$conn = mysqli_connect($servername, $dbusername, $dbpassword, $database);

function send_password_reset($get_name, $get_email, $token)
{
    $postmark_token = '8ef5bbab-b4a3-4efa-8741-19207f41f0c1'; // Replace with your Postmark server token
    $postmark_url = 'https://api.postmarkapp.com/email';

    $headers = array(
        'Content-Type: application/json',
        'X-Postmark-Server-Token: ' . $postmark_token,
    );

    $data = array(
        'From' => 'qdbnrbnq@globalbills.com.ng', // Replace with your email address
        'To' => $get_email,
        'Subject' => 'Reset Password Link',
        'HtmlBody' => "Good day\n\nYou are receiving this email because we received a password reset request for your account.\n\nKindly Click Here: https://Globalbills.com.ng/home/password_change.php?token=$token&email=$get_email\n",
    );

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $postmark_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($ch);
    curl_close($ch);

    $response_data = json_decode($response, true);


    if ($response_data['ErrorCode'] === 0) {
        echo '<script type="text/javascript">alert("A reset link has been sent to your email")</script>';
    } else {
        echo 'Error sending email: ' . $response_data['Message'];
    }
}

if (isset($_POST['submit'])) {
    $email = mysqli_real_escape_string($conn, $_POST["email"]);
    $token = md5(rand());

    $check_email = "SELECT email FROM users WHERE email='$email' LIMIT 1";
    $check_email_run = mysqli_query($conn, $check_email);

    if (mysqli_num_rows($check_email_run) > 0) {
        $row = mysqli_fetch_array($check_email_run);
        $get_name = isset($row['username']) ? $row['username'] : '';
        $get_email = $row['email'];

        $update_token = "UPDATE users SET reset_token='$token' WHERE email='$get_email' LIMIT 1";
        $update_token_run = mysqli_query($conn, $update_token);

        if ($update_token_run) {
            send_password_reset($get_name, $get_email, $token);
            echo '<script type="text/javascript">alert("A reset link has been sent to your email")</script>';
        } else {
            echo '<script type="text/javascript">alert("Somethng went wrong.");</script>';
        }
    } else {
        echo '<script type="text/javascript">alert("Email not found.");</script>';
    }
}
?>
