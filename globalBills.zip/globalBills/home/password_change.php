<?php
session_start();

?>
<!DOCTYPE html>
<html>

<head>
<link rel="icon" type="image/png" size="512x512" href="../css/imgs/EPIbg.png">
    <link rel="stylesheet" href="../css/resetpassword.css">
    <title>Password Change</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>

<body>
    <header>
        <div class="container container-nav">
            <div class="all">
                <div class="logo">
                    <img src="../css/imgs/EPbg.png">
                </div>
                <div class="tilte">
                    <h1>EAZI PLUX</h1>
                    <p class="subtitle">Designed for Eased Payment</p>
                </div>
            </div>
            <div>
                <nav>
                    <ul>
                        <li><a href="../index.php">Home</a></li>
                        <li><a href="ourservices.php">Our Service</a></li>
                        <li><a href="getintouch.php">Get in Touch</a></li>
                        <li><a href="signup.php">Join Us</a></li>
                    </ul>
                </nav>
            </div>
    </header>
    <main>
        <div class="container">
            <h2>Password Change</h2>
            <form method="post" action="">
                <!-- PHP logic moved to 'process_password_change.php' -->
                <div class="txt-field">
                    <input type="password" name="new_password" required>
                    <span></span>
                    <label>New Password:</label>
                </div>
                <div class="txt-field">
                    <input type="password" name="confirm_password" required>
                    <span></span>
                    <label>Confirm New Password:</label>
                </div>
                <div>
                    <input name="submit" type="submit" value="Change Password">
                </div>
            </form>
        </div>
    </main>
</body>

</html>

<?php

$servername = "localhost:3306";  // Replace with your database server name
$dbusername = "qdbnrbnq_global";        // Replace with your database username
$dbpassword = "Sinachi123";  // Replace with your database password
$database = "qdbnrbnq_global"; // Replace with your database name

$conn = mysqli_connect($servername, $dbusername, $dbpassword, $database);

if (isset($_POST['submit'])) {
    $new_password = mysqli_real_escape_string($conn, $_POST["new_password"]);
    $confirm_password = mysqli_real_escape_string($conn, $_POST["confirm_password"]);

    // Check if passwords match
    if ($new_password == $confirm_password) {
        // Retrieve email and reset_token from the URL parameters
        $email = $_GET['email'];
        $token = $_GET['token'];

        // Check if the email and token exist in the database
        $check_token = "SELECT * FROM users WHERE email='$email' AND reset_token='$token' LIMIT 1";
        $check_token_run = mysqli_query($conn, $check_token);

        if (mysqli_num_rows($check_token_run) > 0) {
            // Hash the new password before updating the database
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            // Update the user's password and reset_token in the database
            $update_password = "UPDATE users SET pass_word='$hashed_password', reset_token=NULL WHERE email='$email' AND reset_token='$token' LIMIT 1";
            $update_password_run = mysqli_query($conn, $update_password);

            if ($update_password_run) {
                echo '<script type="text/javascript">alert("Password successfully changed")</script>';
            } else {
                echo '<script type="text/javascript">alert("Error Updating password.")</script>';
            }
        } else {
            echo '<script type="text/javascript">alert("Link Exipred. Request a new link.")</script>';
        }
    } else {
        echo '<script type="text/javascript">alert("Password Does not match.")</script>';
    }
}
// Redirect back to the password_change.php page

?>