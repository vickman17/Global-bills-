<?php
session_start();
$isInvalid = false;

// Replace the external file include with direct connection details
$servername = "localhost:3306";
$db_username = "qdbnrbnq_global";
$db_password = "Sinachi123";
$db_name = "qdbnrbnq_global";

$conn = new mysqli($servername, $db_username, $db_password, $db_name);

// Check for database connection errors
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();

    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && password_verify($password, $user["pass_word"])) {
        $_SESSION['user_id'] = $user['user_id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['email'] = $user['email'];

        $_SESSION['customer_data'] = array(
    "email" => $_SESSION["email"],
    "first_name" => "",
    "last_name" => $_SESSION['username'],
    "phone" => $_SESSION["phone"]
);

// API endpoint URL
$urlCustomer = 'https://api.paystack.co/customer';

// API Key for Authorization
$authorization = 'Authorization: Bearer sk_live_2886d2746575c3f54e3c7b7e02eab1cd7da06313';

// Content type
$contentType = 'Content-Type: application/json';

// Data to be sent in the request
$dataCustomer = json_encode($_SESSION['customer_data']);

// Initialize cURL session
$chCustomer = curl_init();

// Set cURL options for a POST request
curl_setopt($chCustomer, CURLOPT_URL, $urlCustomer);
curl_setopt($chCustomer, CURLOPT_POST, 1);
curl_setopt($chCustomer, CURLOPT_POSTFIELDS, $dataCustomer);
curl_setopt($chCustomer, CURLOPT_RETURNTRANSFER, true);
curl_setopt($chCustomer, CURLOPT_HTTPHEADER, array(
    $authorization,
    $contentType,
));

// Execute cURL session
$responseCustomer = curl_exec($chCustomer);

// Check for cURL errors
if (curl_errno($chCustomer)) {
    echo 'Curl error: ' . curl_error($chCustomer);
} else {
    // Decode and print the response
    $responseDataCustomer = json_decode($responseCustomer, true);


    $customerCode = $responseDataCustomer['data']['customer_code'];

}

// Close cURL session
curl_close($chCustomer);

 $url = "https://api.paystack.co/dedicated_account";
 
 $fields = [
     "customer" => $customerCode,
     "preferred_bank" => "wema-bank"
 ];
 
 $fields_string = http_build_query($fields);
 
 // Initialize cURL session
 $ch = curl_init();
 
 // Set cURL options for a POST request
 curl_setopt($ch, CURLOPT_URL, $url);
 curl_setopt($ch, CURLOPT_POST, true);
 curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
 curl_setopt($ch, CURLOPT_HTTPHEADER, array(
     "Authorization: Bearer sk_live_2886d2746575c3f54e3c7b7e02eab1cd7da06313",
     "Cache-Control: no-cache",
 ));
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 
 // Execute cURL session
 $result = curl_exec($ch);
 
 // Check for cURL errors
 if (curl_errno($ch)) {
     echo 'Curl error: ' . curl_error($ch);
 } else {
    // Decode the result
    $decode = json_decode($result);

    // Extract required information
    $acctnumber = $decode->data->account_number;
    $acctname = $decode->data->account_name;
    $bankname = $decode->data->bank->name;



    // Close cURL session
    curl_close($ch);

    // Save to database
    // Replace the following with your database connection and query
$servername = "localhost:3306";
$db_username = "qdbnrbnq_global";
$db_password = "Sinachi123";
$db_name = "qdbnrbnq_global";

$conn = new mysqli($servername, $db_username, $db_password, $db_name);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare("UPDATE users SET acct_number=?, acct_name=?, bank_name=? WHERE email=?");
    $stmt->bind_param("ssss", $acctnumber, $acctname, $bankname, $_SESSION["email"]);
    $stmt->execute();

    $stmt->close();
    $conn->close();


    $_SESSION['acctnumber'] = $acctnumber;
    $_SESSION['acctname'] = $acctname;
    $_SESSION['bankname'] = $bankname;
}







        header("Location: ../home/dashboard.php");
        exit;
    } else {
        $isInvalid = true;
    }

    // Display specific error messages if the query fails
    if (!$result) {
        echo "Error executing query: " . $conn->error;
    }

    $stmt->close();
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../css/login.css">
    <link rel="icon" type="image/png" size="512x512" href="../css/imgs/EPIbg.png">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>

    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-VVN0P5EYQP">
</script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-VVN0P5EYQP');
</script>
</head>
<body>
    <header>
        <div class="container container-nav">
            <div class="all">
                <div class="logo">
                    <img src="../css/imgs/EPbg.png">
                </div>
                <div class="tilte">
                    <h1>EAZI PLUX</h1>
                    <p class="subtitle">Designed for Eased Payment</p>
                </div>
            </div>
            <nav>
                <ul>
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="ourservices.php">Our Service</a></li>
                    <li><a href="getintouch.php">Get in Touch</a></li>
                    <li><a href="signup.php">Join Us</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>                   
        <div class="cont">
            <div class="column1">
                <img src="../css/imgs/coins.jpg" alt="coins">
            </div>
            <div class="column2">
                <div class="container">
                    <form method="post">
                        <h2>WELCOME TO EAZI PLUX</h2>
                        <h3>
                            <?php if($isInvalid): ?>
                            <em> INVALID CREDENTIALS </em>
                            <?php endif; ?>
                        </h3>
                        <div class="txt-field">
                            <input type="email" name="email" required class="email">
                            <span></span>
                            <label>Email</label>
                        </div>
                        <div class="txt-field">
                            <input type="password" name="password" required class="password">
                            <span></span>
                            <label>Password</label>
                        </div>
                        <div class="forgotpass"><a href="resetpassword.php">Forgot Password?</a></div>
                        <input type="submit" name="submit" class="login" value="Login">
                        <div class="signup">Not a member? <a href="signup.php">Signup</a></div>
                    </form>
                </div>
            </div>
        </div>
    </main>



    <script type="text/javascript">
        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
        (function(){
        var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
        s1.async=true;
        s1.src='https://embed.tawk.to/658c01c070c9f2407f83aa82/1hilednbb';
        s1.charset='UTF-8';
        s1.setAttribute('crossorigin','*');
        s0.parentNode.insertBefore(s1,s0);
        })();
    </script>
</body>
</html>
