<?php 


    $servername = "localhost:3306";  // Replace with your database server name
    $username = "qdbnrbnq_global";        // Replace with your database username
    $dbpassword = "Sinachi123";            // Replace with your database password
    $database = "qdbnrbnq_global"; // Replace with your database name



    $mysqli = new mysqli(
        hostname: $servername,
        username: $username,
        password: $dbpassword,
        database: $database,
    );

    return $mysqli;