<?php
session_start();
$is_invalid = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
$servername = "localhost:3306";  // Replace with your database server name
$username = "qdbnrbnq_global";   // Replace with your database username
$dbpassword = "Sinachi123";      // Replace with your database password
$database = "qdbnrbnq_global";   // Replace with your database name
$conn = new mysqli($servername, $username, $dbpassword, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Check if the email already exists in the database
    $check_email_sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($check_email_sql);
    $stmt->bind_param("s", $_POST['email']);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 0) {
        // Email doesn't exist, proceed with user registration
        $email = $_POST['email'];
        $username = $_POST['username'];
        $phone = $_POST['phone'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

        // SQL query to insert user data into the users table
        $insert_user_sql = "INSERT INTO users (email, username, phone_number, pass_word) 
            VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($insert_user_sql);
        $stmt->bind_param("ssss", $email, $username, $phone, $password);

        if ($stmt->execute()) {
            // User registration successful

            // Get the user ID of the newly inserted user
            $user_id = $conn->insert_id;

            // Create an entry in the virtual account table
            $create_virtual_account_sql = "INSERT INTO virtual_accounts (acct_id, balance) 
                VALUES (?, 0)";
            $stmt = $conn->prepare($create_virtual_account_sql);
            $stmt->bind_param("i", $user_id);

            if ($stmt->execute()) {
                // Virtual account creation successful
                header("Location: login.php");
                exit; // Ensure the script terminates after redirection
            } else {
                echo "Error creating virtual account: " . $stmt->error;
            }
        } else {
            echo "Error creating user: " . $stmt->error;
        }
    } else {
        // Email already exists, show an error message
        $is_invalid = true;
        $error = "Email Already Taken!!!";
        $_SESSION['emailerror'] = $error;
    }

    $stmt->close();
    $conn->close();
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" type="image/png" size="512x512" href="../css/imgs/EPIbg.png">
    <link rel="stylesheet" href="../css/signup.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>

    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-VVN0P5EYQP">
</script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-VVN0P5EYQP');
</script>
</head>
<body>
    <header>
        <div class="container container-nav">
            <div class="all">
                <diV class="logo">
                    <img src="../css/imgs/EPbg.png">
                </div>
                <div class="tilte">
                    <h1>EAZI PLUX</h1>
                    <p class="subtitle">Designed for Eased Payment</p>
                </div>
            </div>
            <nav>
                <ul>
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="ourservices.php">Our Service</a></li>
                    <li><a href="getintouch.php">Get in Touch</a></li>
                    <li><a href="signup.php">Join Us</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>                   
        <div class="cont">
            <div class="column1">
                <img src="../css/imgs/happycash.jpg" alt="coins">
            </div>
            <div class="column2">
                <div class="container">
                    <form method="post">
                        <h2>WELCOME TO EAZI PLUX</h2>
                        <?php if (isset($_SESSION["emailerror"])): ?>
                            <p><?php echo $_SESSION["emailerror"]; ?></p>
                        <?php endif; ?>

                        <p>Fill in Your Details</p>
                        <div class="txt-field">
                            <input type="email" name="email" required class="email">
                            <span></span>
                            <label>Email</label>
                        </div>
                        <div class="txt-field">
                            <input type="username" name="username" required class="username">
                            <span></span>
                            <label>Username</label>
                        </div>
                        <div class="txt-field">
                            <input type="phone" name="phone" required class="phone">
                            <span></span>
                            <label>Phone Number</label>
                        </div>
                        <div class="txt-field">
                            <input type="password" name="password" required class="password">
                            <span></span>
                            <label>Password</label>
                        </div>
                        <div class="remeber">
                            <input type="checkbox">
                            <label>Remeber Me</label>
                        </div>
                        <input type="submit" class="login" value="Register">
                        <div class="signup">Already a member? <a href="login.php">Login</a></div>
                    </form>
                </div>
            </div>
        </div>
    </main>


    <script type="text/javascript">
        var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
        (function(){
        var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
        s1.async=true;
        s1.src='https://embed.tawk.to/658c01c070c9f2407f83aa82/1hilednbb';
        s1.charset='UTF-8';
        s1.setAttribute('crossorigin','*');
        s0.parentNode.insertBefore(s1,s0);
        })();
    </script>
</body>
</html>