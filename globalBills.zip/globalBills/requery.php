<?php
session_start();

function requeryDedicatedAccount($accountNumber, $providerSlug, $secretKey)
{
    $url = "https://api.paystack.co/dedicated_account/requery?account_number=$accountNumber&provider_slug=$providerSlug";
    $authorization = "Authorization: Bearer $secretKey";
    $content_type = "Content-Type: application/json";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array($authorization, $content_type));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    $response = curl_exec($ch);

    if ($response === false) {
        echo 'Curl error: ' . curl_error($ch);
    } else {
        // Handle the requery response as needed
        echo $response;
    }

    curl_close($ch);
}

// Replace with your actual values
$accountNumber = $_SESSION["acctno"];
$providerSlug = "wema-bank";
$secretKey = "sk_test_52abab6d03bd7939f8eee9f38f5c391ac69ce37c";

while (true) {
    // Run the requery function
    requeryDedicatedAccount($accountNumber, $providerSlug, $secretKey);

    // Wait for 3 seconds before requerying again
    sleep(6000000000000000000000000000000000000000);
}

?>