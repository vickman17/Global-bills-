<?php 
    session_start();
?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="../css/mtnairtime.css">
        <link rel="icon" type="image/png" size="662x662" href="../css/imgs/EPIbg.png">
        <script src="https://kit.fontawesome.com/49c5823e25.js" crossorigin="anonymous"></script>
        <meta name="description" content="Manage your mobile data and pay bills seamlessly with Eazi Plux. Enjoy a convienient and secure platform for handling all your mobile-related transactions.">
        <meta charset="UTF-8">
        <meta name="keywords" content="discounted mobile data, airtime deals, bills payment app, online payment, mobile recharge, discounted airtime, bill management, digital transactions, cheap airtime, cheap data, Eazi Plux, best cheap data ">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="google-site-verification" content="2C-9r_1lFbvzBCAMqcq3p8EoPsKWrm_9aiWJWioJiVg" />
        <meta name="author" content="Vickman Tech">
        <title>9mobile Data</title>
    </head>
    <style>
        span{
            color: gray;
        }
    </style>
    <body>
        <header>
        <div class="container container-nav">
                <div class="all">
                    <diV class="logo">
                        <img src="../css/imgs/EPbg.png">
                    </div>
                    <div class="tilte">
                        <h1>EAZI PLUX</h1>
                        <p class="subtitle">Designed for Eased Payment</p>
                    </div>
                </div>
                <nav>
                <ul>
                    <li><a href="../home/dashboard.php">Dashboard</a></li>
                    <li><a href="../dashboard/buyairtime.php">Airtime</a></li>
                    <li><a href="../dashboard/tvsub.php">Tv Subcription</a></li>
                    <li><a href="../home/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
        </header>


        <main>
            <div class="container">
                <div class="network">
                    <form method="post">
                    <div class="MOBILEMTN">
                        <a href="../data/9mobiledata.php">
                            <div class="mtnlogo">
                                <img src="../css/imgs/9mobiledataupdate.png" alt="mtn">
                            </div>
                        </a>
                    </div>
                        <label>DATA PLANS:</label>
                        <div>
                            <select id="plans" name="plans">
                                <?php 
                                    $curl = curl_init();

                                    curl_setopt_array($curl, array(
                                        CURLOPT_URL => 'https://gsubz.com/api/plans?service=etisalat_data',
                                        CURLOPT_RETURNTRANSFER => true,
                                        CURLOPT_ENCODING => '',
                                        CURLOPT_MAXREDIRS => 10,
                                        CURLOPT_TIMEOUT => 0,
                                        CURLOPT_FOLLOWLOCATION => true,
                                        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                                        CURLOPT_CUSTOMREQUEST => 'GET',
                                    ));

                                    $response = curl_exec($curl);

                                    curl_close($curl);

                                    // Decode the JSON response
                                    $responseArray = json_decode($response, true);

                                    // Check if JSON decoding was successful
                                    if ($responseArray !== null) {
                                        // Iterate through the plans to generate options for the dropdown
                                        $plans = $responseArray['plans'];

                                        $options = '';
                                        foreach ($plans as $plan) {
                                            $displayName = $plan['displayName'];
                                            $value = $plan['value'];
                                            $price = $plan['price'];

                                            // Calculate the adjusted price with an additional 10%
                                            $adjustedPrice = $price + ($price * 0.095);
                                            $adjustedPrice = floor($adjustedPrice);

                                            $options .= "<option value='$value'>$displayName - $adjustedPrice</option>";
                                        }

                                        echo $options;
                                    } else {
                                        // Handle JSON decoding error
                                        echo "Error decoding JSON response.";
                                    }
                                    ?>
                            </select>
                        </div>
                        <label>Phone Number</label>
                        <div>
                            <input type="text" class="number" name="number" placeholder="Phone Number..E.g 08012345678">
                        </div>
                        <input class="submit" name="submit" type="submit" value="Buy Data">
                    </form>
                </div>
            </div>
        </main>
    </body>
</html>



<?php

// Function to make an API request
function makeApiRequest($url)
{
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
    ));

    $response = curl_exec($curl);

    if ($response === false) {
        // Handle API request failure
        die("Error making API request: " . curl_error($curl));
    }

    curl_close($curl);

    // Decode the JSON response
    $responseArray = json_decode($response, true);

    if ($responseArray === null) {
        // Handle JSON decoding error
        die("Error decoding JSON response.");
    }

    return $responseArray;
}


    $servername = "localhost:3306";  // Replace with your database server name
$dbusername = "qdbnrbnq_global";   // Replace with your database username
$dbpassword = "Sinachi123";      // Replace with your database password
$database = "qdbnrbnq_global";   // Replace with your database name
$conn = new mysqli($servername, $dbusername, $dbpassword, $database);

// Check if the connection is successful
if ($conn->connect_errno) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve user data from session
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];

    // Fetch user ID
    $user_id_query = "SELECT user_id FROM users WHERE username = '$username'";
    $result = $conn->query($user_id_query);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $user_id = $row["user_id"];

        // Fetch user balance
        $balance_query = "SELECT balance FROM virtual_accounts WHERE acct_id = $user_id";
        $balance_result = $conn->query($balance_query);

        if ($balance_result->num_rows == 1) {
            $balance_row = $balance_result->fetch_assoc();
            $account_balance = $balance_row["balance"];

            $_SESSION["USER_ID"] = $user_id;
            $_SESSION['ACCT'] = $account_balance;
        } else {
            $account_balance = 0; // Default balance if not found
        }
    } else {
        // Handle the case where the user's ID is not found
    }
} else {
    header("Location: ../home/login.php"); // Redirect to the login page
    exit;
}

// Fetch data plans from the API
$responseArray = makeApiRequest('https://gsubz.com/api/plans?service=etisalat_data');
$phoneNumber = str_replace(' ', "", $_POST['number']);

// Check if the transaction status is TRANSACTION_FAILED
function handleTransactionFailure($responseArray, $number, $conn)
{
    $failureReason = $responseArray["description"];
    $failureStatus = $responseArray["status"]; 

    $transaction_description = "9mobile Data Purchase for " . $number;
    $transaction_status = "FAILED";
    $transaction_id = "GB" . $_SESSION['USER_ID'] . time();

    // Insert failed transaction details into the transaction_history table
    $log_transaction_query = "INSERT INTO transaction_history (user_id, transaction_id, amount, description, status) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($log_transaction_query);
    $stmt->bind_param("issss", $_SESSION['USER_ID'], $transaction_id, $_SESSION['amount'], $transaction_description, $transaction_status);
    $stmt->execute();

    if ($failureReason === "INSUFFICIENT_BALANCE") {
        // Handle insufficient balance error
        $_SESSION['message'] = "Service Currently Down: Try again in 5 minutes or Contact US.";
    }elseif($failureStatus === "failed"){
        $_SESSION['message'] = "Transaction Failed: Try again.";
    }elseif($failureStatus === "Reversed"){
        $_SESSION["message"] = "Transaction Failed: Money Reversed";
    }else{
        // Handle other transaction failure reasons as needed
        $_SESSION['message'] = "Transaction failed: $failureReason";
    }

    header("Location: ../failed.php");
    exit;
}

// Check if the form is submitted
if (isset($_POST['submit'])) {
    $selectedPlanValue = isset($_POST['plans']) ? $_POST['plans'] : '';
    $selectedPlanPrice = '';

    // Find the selected plan's price
    foreach ($responseArray['plans'] as $plan) {
        if ($plan['value'] == $selectedPlanValue) {
            $selectedPlanPrice = $plan['price'];
            break;
        }
    }

    // Adjust the selected plan price
    $adjustedPrice = $selectedPlanPrice + $selectedPlanPrice * 0.095;
    $adjustedPrice = floor($adjustedPrice);

    // Store the selected amount in the session
    $_SESSION['amount'] = $adjustedPrice;

    // Check if the user's virtual account balance is sufficient
    if ($account_balance < $_SESSION['amount']) {
        $transaction_description = "9mobile Data Purchase for " . $number;
        $transaction_status = "FAILED";
        $transaction_id = "GB" . $_SESSION['USER_ID'] . time();
    
        // Insert failed transaction details into the transaction_history table
        $log_transaction_query = "INSERT INTO transaction_history (user_id, transaction_id, amount, description, status) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($log_transaction_query);
        $stmt->bind_param("issss", $_SESSION['USER_ID'], $transaction_id, $_SESSION['amount'], $transaction_description, $transaction_status);
        $stmt->execute();


        $_SESSION['message'] = "Transaction failed: Fund your Global Bills Wallet.";
        header("Location: ../failed.php");
    } else {
        // If the balance is sufficient, proceed with the purchase
        purchaseData($adjustedPrice, $phoneNumber, $selectedPlanValue, $conn);
    }
}

// Function to handle the purchase logic
function purchaseData($adjustedPrice, $phoneNumber, $selectedPlanValue, $conn)
{
    // Use the captured data to make the purchase API request
    $curl = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://gsubz.com/api/pay/',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => array(
            'serviceID' => 'etisalat_data',
            'plan' => $selectedPlanValue,
            'api' => 'ap_3f856a5b46bb740150d03c990ce2f5d7',
            'amount' => $adjustedPrice,
            'phone' => $phoneNumber,
            'requestID' => "GB" . uniqid()
        ),
        CURLOPT_HTTPHEADER => array(
            'Authorization: Bearer ap_3f856a5b46bb740150d03c990ce2f5d7'
        ),
    ));

    $response = curl_exec($curl);

    curl_close($curl);

    // Decode the JSON response
    $responseArray = json_decode($response, true);

    // Check if the transaction status is TRANSACTION_FAILED
    if ($responseArray["status"] === "TRANSACTION_FAILED") {
        handleTransactionFailure($responseArray, $phoneNumber, $conn);
    }elseif($responseArray["status"] === "failed"){
        $_SESSION["message"] = "Transaction failed: Check Number or Try again later.";
        header("Location: ../failed.php");
    }else {
        // Transaction was successful, update the balance in the database
        $new_balance = $_SESSION['ACCT'] - $adjustedPrice;
        $update_balance_query = "UPDATE virtual_accounts SET balance = $new_balance WHERE acct_id = {$_SESSION['USER_ID']}";
        $conn->query($update_balance_query);

        $transaction_description = "9mobile Data Purchase for " . $phoneNumber;
        $transaction_status = "SUCCESS";
        $transaction_id = "GB" . $_SESSION['USER_ID'] . time();

        // Insert successful transaction details into the transaction_history table
        $log_transaction_query = "INSERT INTO transaction_history (user_id, transaction_id, amount, description, status) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($log_transaction_query);
        $stmt->bind_param("issss", $_SESSION['USER_ID'], $transaction_id, $_SESSION['amount'], $transaction_description, $transaction_status);
        $stmt->execute();

        // Echo a success message or perform any other actions as needed
        $_SESSION['message'] = 'You Have Purchased ' . $_SESSION['amount'] . ' naira worth of 9MOBILE DATA';
        header("Location: ../success.php");
        exit;
    }
}

// HTML structure remains unchanged
?>
