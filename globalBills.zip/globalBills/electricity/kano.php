<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="../css/mtnairtime.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" size="662x662" href="../css/imgs/EPIbg.png">
    <script src="https://kit.fontawesome.com/49c5823e25.js" crossorigin="anonymous"></script>
    <meta name="description" content="Manage your mobile data and pay bills seamlessly with Eazi Plux. Enjoy a convienient and secure platform for handling all your mobile-related transactions.">
    <meta charset="UTF-8">
    <meta name="keywords" content="discounted mobile data, airtime deals, bills payment app, online payment, mobile recharge, discounted airtime, bill management, digital transactions, cheap airtime, cheap data, Eazi Plux, best cheap data ">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="google-site-verification" content="2C-9r_1lFbvzBCAMqcq3p8EoPsKWrm_9aiWJWioJiVg" />
    <meta name="author" content="Vickman Tech">
    <title>KANO ELECTRICITY</title>
    <style>
        span {
            color: green;
        }
    </style>
</head>

<body>
    <header>
        <div class="container container-nav">
                <div class="all">
                    <diV class="logo">
                        <img src="../css/imgs/EPbg.png">
                    </div>
                    <div class="tilte">
                        <h1>EAZI PLUX</h1>
                        <p class="subtitle">Designed for Eased Payment</p>
                    </div>
                </div>
            <nav>
                <ul>
                    <li><a href="../home/dashboard.php">Dashboard</a></li>
                    <li><a href="../dashboard/buyairtime.php">Airtime</a></li>
                    <li><a href="../dashboard/buydata.php">Data</a></li>
                    <li><a href="../home/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <div class="container">
            <div class="network">
                <form method="post">
                    <div class="MOBILEMTN">
                        <a href="../electricity/kano.php">
                            <div class="mtnlogo">
                                <img src="../css/imgs/kano.png" alt="KANO">
                            </div>
                        </a>
                    </div>
                    <label>AMOUNT:</label>
                    <div>
                        <input type="text" class="amount" name="amount" placeholder="E.g...100"></input>
                    </div>

                    <label>Phone Number:</label>
                    <div>
                        <input type="text" class="number" name="number" placeholder="E.g...08012345678">
                    </div>

                    <label>Customer ID:</label>
                    <div>
                        <input type="text" class="customer" name="customer" placeholder="E.g...939012345678">
                    </div>
                    <input class="submit" name="submit" type="submit" value="Buy Electricity">
                </form>
            </div>
        </div>
    </main>
</body>

</html>


<?php
session_start();

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];

    // Establish a database connection (use your database connection code here)
    $servername = "localhost:3306";  // Replace with your database server name
    $db_username = "qdbnrbnq_global";        // Replace with your database username
    $db_password = "Sinachi123";            // Replace with your database password
    $db_name = "qdbnrbnq_global"; // Replace with your database name



    $conn = new mysqli($servername, $db_username, $db_password, $db_name);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve the user's virtual account balance
    // Assuming you store the username in the $_SESSION
    $username = $_SESSION['username'];

    // SQL query to fetch the user's ID based on their username
    $user_id_query = "SELECT user_id FROM users WHERE username = '$username'";
    $result = $conn->query($user_id_query);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $user_id = $row["user_id"];
        // Now that you have the user's ID, you can retrieve their balance
        $balance_query = "SELECT balance FROM virtual_accounts WHERE acct_id = $user_id";
        $balance_result = $conn->query($balance_query);

        if ($balance_result->num_rows == 1) {
            $balance_row = $balance_result->fetch_assoc();
            $account_balance = $balance_row["balance"];
        } else {
            $account_balance = 0; // Default balance if not found
        }
    } else {
        // Handle the case where the user's ID is not found
    }
} else {
    header("Location: ../home/login.php"); // Redirect to the dashboard page
    exit;
}

// Check if "number" and "amount" keys are set in the $_POST array
$number = isset($_POST["number"]) ? $_POST["number"] : null;
$amount = isset($_POST["amount"]) ? $_POST["amount"] : null;
$customer = isset($_POST["customer"]) ? $_POST["customer"] : null;
$responseMessage = null;

// Check if the account balance is sufficient
if (isset($_POST["submit"])) {
    if (!is_numeric($amount) || $amount < 100) {
        $responseMessage = "Amount must be numeric and at least 100 naira.";
        $_SESSION['message'] = $responseMessage;
        header("Location: ../failed.php");
    } elseif ($account_balance < $amount) {
        $transaction_description = "KANO ELECTRICITY PAYMENT FOR " . $customer;
        $transaction_status = "FAILED";
        $transaction_id = "GB" . $_SESSION['USER_ID'] . time();
    
        // Insert failed transaction details into the transaction_history table
        $log_transaction_query = "INSERT INTO transaction_history (user_id, transaction_id, amount, description, status) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($log_transaction_query);
        $stmt->bind_param("issss", $_SESSION['USER_ID'], $transaction_id, $amount, $transaction_description, $transaction_status);
        $stmt->execute();

        $responseMessage = 'Transaction failed: Fund your Global Bills wallet.';
        $_SESSION['message'] = $responseMessage;
        header('Location: ../failed.php');
    } else {
        // Deduct the specified amount from the user's virtual account balance

        // Proceed with the transaction
        $curl = curl_init();

        curl_setopt_array(
            $curl,
            array(
                CURLOPT_URL => 'https://gsubz.com/api/pay/',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => array('serviceID' => 'kano_electric', 'api' => 'ap_83c2ee17ca19e2c34e29a0f17cd5bd89', 'amount' => $amount, 'phone' => $number, 'customerID' => $customer),
                CURLOPT_HTTPHEADER => array(
                    'api: Bearer ap_83c2ee17ca19e2c34e29a0f17cd5bd89'
                ),
            )
        );

        $response = curl_exec($curl);

        curl_close($curl);

        echo '<pre>';
        print_r($response);
        echo '</pre>';

        // Your existing cURL request code

        $response = json_decode($response, true);

        if ($response['status'] === 'TRANSACTION_FAILED') {
            $transaction_description = "KANO ELECTRICITY PAYMENT FOR " . $customer;
            $transaction_status = "FAILED";
            $transaction_id = "GB" . $_SESSION['USER_ID'] . time();
        
            // Insert failed transaction details into the transaction_history table
            $log_transaction_query = "INSERT INTO transaction_history (user_id, transaction_id, amount, description, status) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($log_transaction_query);
            $stmt->bind_param("issss", $_SESSION['USER_ID'], $transaction_id, $amount, $transaction_description, $transaction_status);
            $stmt->execute();
    
            // Check the description for specific failure reasons
            if (strpos($response['description'], 'AMOUNT_ABOVE_MAX') !== false) {
                $responseMessage = 'Transaction failed: Amount above maximum allowed.';
                $_SESSION['message'] = $responseMessage;
                header("Location: ../failed.php");
                
            } elseif (strpos($response['description'], 'INSUFFICIENT_BALANCE') !== false) {
                $responseMessage = 'Service Currently Down: Try again in 5 minutes or Contact Us.';
                $_SESSION["message"] = $responseMessage;
                header("Location: ../failed.php");
            } else {
                $responseMessage = 'Service Currently Down: Try again in 5 minutes or Contact Us.';
                $_SESSION['message'] = $responseMessage;
                header("Location: ../failed.php");
            }
        } else {
            $transaction_description = "KANO ELECTRICITY PAYMENT FOR " . $customer;
            $transaction_status = "SUCCESS";
            $transaction_id = "GB" . $_SESSION['USER_ID'] . time();
        
            // Insert failed transaction details into the transaction_history table
            $log_transaction_query = "INSERT INTO transaction_history (user_id, transaction_id, amount, description, status) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($log_transaction_query);
            $stmt->bind_param("issss", $_SESSION['USER_ID'], $transaction_id, $amount, $transaction_description, $transaction_status);
            $stmt->execute();
    
            // Handle other cases if needed
            $new_balance = intval($account_balance) - intval($amount);

            // Update the balance in the database
            $update_balance_query = "UPDATE virtual_accounts SET balance = $new_balance WHERE acct_id = $user_id";
            $conn->query($update_balance_query);

            $responseMessage = 'You have successfully paid the sum of '.$amount.' for KANO ELECTRICITY for '.$customer;
            $_SESSION["message"] = $responseMessage;
            header("Location: ../success.php"); // Redirect to the dashboard page
            exit;
        }
    }
}
?>