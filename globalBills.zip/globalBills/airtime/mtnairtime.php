<!DOCTYPE html>
<html lang="en">

<head>
    <link rel="stylesheet" href="../css/mtnairtime.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" size="662x662" href="../css/imgs/EPIbg.png">
    <script src="https://kit.fontawesome.com/49c5823e25.js" crossorigin="anonymous"></script>
    <meta name="description" content="Manage your mobile data and pay bills seamlessly with Eazi Plux. Enjoy a convienient and secure platform for handling all your mobile-related transactions.">
    <meta charset="UTF-8">
    <meta name="keywords" content="discounted mobile data, airtime deals, bills payment app, online payment, mobile recharge, discounted airtime, bill management, digital transactions, cheap airtime, cheap data, Eazi plux, best cheap data ">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="google-site-verification" content="2C-9r_1lFbvzBCAMqcq3p8EoPsKWrm_9aiWJWioJiVg" />
    <meta name="author" content="Vickman Tech">
    <title>MTN recharge</title>

    <style>
        span {
            color: green;
        }
    </style>
</head>

<body>
    <header>
        <div class="container container-nav">
                <div class="all">
                    <diV class="logo">
                        <img src="../css/imgs/EPbg.png">
                    </div>
                    <div class="tilte">
                        <h1>EAZI PLUX</h1>
                        <p class="subtitle">Designed for Eased Payment</p>
                    </div>
                </div>
            <nav>
                <ul>
                    <li><a href="../home/dashboard.php">Dashboard</a></li>
                    <li><a href="../dashboard/buydata.php">Data</a></li>
                    <li><a href="../dashboard/tvsub.php">Tv subscription</a></li>
                    <li><a href="../home/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <div class="container">
            <div class="network">
                <form method="post">
                    <div class="MOBILEMTN">
                        <a href="../airtime/gloairtime.php">
                            <div class="mtnlogo">
                                <img src="../css/imgs/mtnupdate.png" alt="MTN">
                            </div>
                        </a>
                    </div>
                    <label>AMOUNT</label>
                    <div>
                        <input type="text" class="amount" name="amount" placeholder="Amount..E.g 100"></input>
                    </div>
                    <label>Phone Number</label>
                    <div>
                        <input type="text" class="number" name="number" placeholder="Phone Number..E.g 08012345678">
                    </div>
                    <input class="submit" name="submit" onclick="openPopup()" type="submit" value="Buy Airtime">
                </form>
            </div>
    </main>

</body>

</html>


<?php
session_start();

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];

    $servername = "localhost:3306";  // Replace with your database server name
$username = "qdbnrbnq_global";   // Replace with your database username
$dbpassword = "Sinachi123";      // Replace with your database password
$database = "qdbnrbnq_global";   // Replace with your database name
$conn = new mysqli($servername, $username, $dbpassword, $database);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve the user's virtual account balance
    // Assuming you store the username in the $_SESSION
    $username = $_SESSION['username'];

    // SQL query to fetch the user's ID based on their username
    $user_id_query = "SELECT user_id FROM users WHERE username = '$username'";
    $result = $conn->query($user_id_query);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $user_id = $row["user_id"];
        // Now that you have the user's ID, you can retrieve their balance
        $balance_query = "SELECT balance FROM virtual_accounts WHERE acct_id = $user_id";
        $balance_result = $conn->query($balance_query);

        if ($balance_result->num_rows == 1) {
            $balance_row = $balance_result->fetch_assoc();
            $account_balance = $balance_row["balance"];
        } else {
            $account_balance = 0; // Default balance if not found
        }
    } else {
        // Handle the case where the user's ID is not found
    }
} else {
    header("Location: ../home/login.php"); // Redirect to the dashboard page
    exit;
}

// Check if "number" and "amount" keys are set in the $_POST array
$number = isset($_POST["number"]) ? $_POST["number"] : null;
$amount = isset($_POST["amount"]) ? $_POST["amount"] : null;
$responseMessage = null;

// Check if the account balance is sufficient
if (isset($_POST["submit"])) {
    if (!is_numeric($amount) || $amount < 100 || !preg_match('/^\d{11}$/', $number)) {
        $responseMessage = "Invalid input. Please enter a numeric amount above 100 and a valid 11-digit phone number.";
        $_SESSION['message'] = $responseMessage;
        header("Location: ../failed.php");
        exit;
    } elseif ($account_balance < $amount) {
        $responseMessage = 'Transaction failed: Fund your Global Bills Wallet.';
        $transaction_description = "MTN Airtime Purchase for ".$number;
        $transaction_status = "FAILED";
        $transaction_id = "GB" . $user_id . time(); // Combine user ID and timestamp

        // Insert failed transaction details into the transaction_history table
        $log_transaction_query = "INSERT INTO transaction_history (user_id, transaction_id, amount, description, status) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($log_transaction_query);
        $stmt->bind_param("issss", $user_id, $transaction_id, $amount, $transaction_description, $transaction_status);
        $stmt->execute();

        $_SESSION['message'] = $responseMessage;
        header("Location: ../failed.php");
        exit;
    }elseif($response['status'] === "failed"){
            $transaction_description = "MTN Airtime Purchase for ".$number;
            $transaction_status = "FAILED";
            $transaction_id = "GB" . $user_id . time(); // Combine user ID and timestamp

            // Insert failed transaction details into the transaction_history table
            $log_transaction_query = "INSERT INTO transaction_history (user_id, transaction_id, amount, description, status) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($log_transaction_query);
            $stmt->bind_param("issss", $user_id, $transaction_id, $amount, $transaction_description, $transaction_status);
            $stmt->execute();


            $responseMessage = 'Transaction failed: Reversed.';
            $_SESSION["message"] = $responseMessage;
            header("Location: ../failed.php");
        }else {
        // Deduct the specified amount from the user's virtual account balance

        // Proceed with the transaction
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://gsubz.com/api/pay/',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => array('serviceID' => 'mtn', 'api' => 'ap_3f856a5b46bb740150d03c990ce2f5d7', 'amount' => $amount, 'phone' => $number),
            CURLOPT_HTTPHEADER => array(
                'api: Bearer ap_3f856a5b46bb740150d03c990ce2f5d7'
            ),
        ));

        $responses = curl_exec($curl);

        curl_close($curl);

        // Your existing cURL request code

        $response = json_decode($responses, true);

        if ($response['status'] === 'TRANSACTION_FAILED') {
            $transaction_description = "MTN Airtime Purchase for ".$number;
            $transaction_status = "FAILED";
            $transaction_id = "GB" . $user_id . time(); // Combine user ID and timestamp

            // Insert failed transaction details into the transaction_history table
            $log_transaction_query = "INSERT INTO transaction_history (user_id, transaction_id, amount, description, status) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($log_transaction_query);
            $stmt->bind_param("issss", $user_id, $transaction_id, $amount, $transaction_description, $transaction_status);
            $stmt->execute();
            // Check the description for specific failure reasons
            if (strpos($response['description'], 'AMOUNT_ABOVE_MAX') !== false) {
                $responseMessage = 'Transaction failed: Amount above maximum allowed.';
                $_SESSION['message'] = $responseMessage;
                header("Location: ../failed.php");
                die;
            } elseif (strpos($response['description'], 'INSUFFICIENT_BALANCE') !== false) {
                $responseMessage = 'Services Currently Down: Try Again in 5 Minute or Contact Us.';
                $_SESSION['message'] = $responseMessage;
                header("Location: ../failed.php");
                die;
            } else {
                $responseMessage = 'Services Currently Down: Try Again in 5 Minute or Contact Us.';
                $_SESSION["message"] = $responseMessage;
                header("Location: ../failed.php");
            }


        } else {
            // Handle other cases if needed
            $new_balance = intval($account_balance) - intval($amount);

            // Update the balance in the database using prepared statement
            $update_balance_query = "UPDATE virtual_accounts SET balance = ? WHERE acct_id = ?";
            $stmt = $conn->prepare($update_balance_query);
            $stmt->bind_param("ii", $new_balance, $user_id);
            $stmt->execute();

            $responseMessage = 'YOU HAVE SUCCESSFULLY PURCHASED MTN AIRTIME WORTH OF N' . $amount;
            $transaction_description = "MTN Airtime Purchase for ".$number;
            $transaction_status = "SUCCESS";
            $transaction_id = "GB" . $user_id . time(); // Combine user ID and timestamp

            // Insert successful transaction details into the transaction_history table
            $log_transaction_query = "INSERT INTO transaction_history (user_id, transaction_id, amount, description, status) VALUES (?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($log_transaction_query);
            $stmt->bind_param("issss", $user_id, $transaction_id, $amount, $transaction_description, $transaction_status);
            $stmt->execute();

            $_SESSION["message"] = $responseMessage;
            header("Location: ../success.php");
            exit;
        }
    }
}

$_SESSION['message'] = $responseMessage;
?>
