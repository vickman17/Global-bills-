<?php
session_start();
// Replace with your actual Paystack secret key
$paystackSecretKey = 'sk_live_2886d2746575c3f54e3c7b7e02eab1cd7da06313';
$amount = null;


// Function to create a Paystack payment
function createPaystackPayment($email, $amount, $reference)
{
    global $paystackSecretKey;

    $url = 'https://api.paystack.co/transaction/initialize';

    $data = [
        'email' => $email,
        'amount' => $amount,
        'reference' => $reference,
    ];

    $headers = [
        'Authorization: Bearer ' . $paystackSecretKey,
        'Content-Type: application/json',
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true);
}

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the entered amount from the form
    $amount = $_POST['amount']*100;

    // Example email (you may retrieve this from your user system)
    $email = $_SESSION["email"];

    // Generate a unique reference
    $reference = "EP".time();

    // Create Paystack payment
    $paymentData = createPaystackPayment($email, $amount, $reference);

    // Check if payment creation was successful
    if ($paymentData['status']) {
        // Payment creation successful
        $paymentLink = $paymentData['data']['authorization_url'];
        $accessCode = $paymentData['data']['access_code'];

        // Redirect the customer to the payment link
        header("Location: $paymentLink");
        exit;
    } else {
        // Payment creation failed
        
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="../css/cardpayment.css">
    <meta charset="UTF-8">

    <title>Paystack Payment Form</title>
</head>
<body>

<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
<div class="top">
    <label for="amount">Enter Amount (NGN):</label>
    <input type="number" id="amount" name="amount" min="1" required>
    </div>
    <br>
    <button type="submit">Proceed to Pay</button>
</form>

</body>

    <script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/658c01c070c9f2407f83aa82/1hilednbb';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
</html>
