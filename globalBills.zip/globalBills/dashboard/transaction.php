<?php
session_start();

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];

    // Establish a database connection (use your database connection code here)
$servername = "localhost:3306";  // Replace with your database server name
$db_username = "qdbnrbnq_global";   // Replace with your database username
$dbpassword = "Sinachi123";      // Replace with your database password
$database = "qdbnrbnq_global";   // Replace with your database name
$conn = new mysqli($servername, $db_username, $dbpassword, $database);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Retrieve the user's ID based on their username
    $user_id_query = "SELECT user_id FROM users WHERE username = '$username'";
    $result = $conn->query($user_id_query);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $user_id = $row["user_id"];

        // Fetch transaction history for the user
        $transaction_query = "SELECT * FROM transaction_history WHERE user_id = $user_id ORDER BY timestamp DESC";
        $transaction_result = $conn->query($transaction_query);

        if ($transaction_result->num_rows > 0) {
            ?>
            <!DOCTYPE html>
            <html lang="en">
            <head>
                <link rel="stylesheet" href="../css/transaction.css">
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="icon" type="image/png" size="662x662" href="../css/imgs/EPIbg.png">
                <script src="https://kit.fontawesome.com/49c5823e25.js" crossorigin="anonymous"></script>
                <meta name="description" content="Manage your mobile data and pay bills seamlessly with Eazi Plux. Enjoy a convienient and secure platform for handling all your mobile-related transactions.">
                <meta charset="UTF-8">
                <meta name="keywords" content="discounted mobile data, airtime deals, bills payment app, online payment, mobile recharge, discounted airtime, bill management, digital transactions, cheap airtime, cheap data, Eazi Plux, best cheap data ">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <meta name="google-site-verification" content="2C-9r_1lFbvzBCAMqcq3p8EoPsKWrm_9aiWJWioJiVg" />
                <meta name="author" content="Vickman Tech">
                <title>Transaction History</title>
                <style>
                    .failed {
                        color: red;
                    }
                </style>
            </head>
            <body>
                <header>
                    <!-- Your header code goes here -->
                    <div class="container container-nav">
                <div class="all">
                    <diV class="logo">
                        <img src="../css/imgs/EPbg.png">
                    </div>
                    <div class="tilte">
                        <h1>EAZI PLUX</h1>
                        <p class="subtitle">Designed for Eased Payment</p>
                    </div>
                </div>
                <nav>
                <ul>
                    <li><a href="../home/dashboard.php">Dashboard</a></li>
                    <li><a href="../dashboard/buyairtime.php">Airtime</a></li>
                    <li><a href="../dashboard/tvsub.php">Tv Subcription</a></li>
                    <li><a href="../home/logout.php">Logout</a></li>
                </ul>
            </nav>
        </div>
                </header>
                <main>
                    <div class="container">
                        <h3>Transaction History</h3>
                        <div class="column1">
                            <div class="col1">
                                <h4>REF ID</h4>
                            </div>
                            <div class="col1">
                                <h4>Amount</h4>
                            </div>
                            <div class="col1">
                                <h4>Description</h4>
                            </div>
                            <div class="col1">
                                <h4>Status</h4>
                            </div>
                        </div>
                        <?php
                        while ($row = $transaction_result->fetch_assoc()) {
                            echo '<div class="column">';
                            echo '<div class="col"><b>' . $row['transaction_id'] . '</b></div>';
                            echo '<div class="col">' . $row['amount'] . '</div>';
                            echo '<div class="col">' . $row['description'] . '</div>';
                            echo '<div class="col ' . ($row['status'] === 'FAILED' ? 'failed' : '') . '"><b>' . $row['status'] . '</b></div>';
                            echo '</div>';

                                
                            
                        }
                        ?>
                    </div>
                </main>
            </body>

            <script type="text/javascript">
                var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
                (function(){
                var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
                s1.async=true;
                s1.src='https://embed.tawk.to/658c01c070c9f2407f83aa82/1hilednbb';
                s1.charset='UTF-8';
                s1.setAttribute('crossorigin','*');
                s0.parentNode.insertBefore(s1,s0);
                })();
            </script>
            </html>
            <?php
        } else {
            echo "No transactions found.";
        }
    } else {
        echo "User not found.";
    } 
}else {
header("Location: ../home/login.php"); // Redirect to the login page
exit;
}
?>
